

#import <UIKit/UIKit.h>

@interface shakeWindow : UIWindow {

}

@end
