//
//  ShakeAppDelegate.h
//  Shake4
//
//  Created by goodmao on 12-7-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShakeViewController.h"

@interface ShakeAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (retain, nonatomic) ShakeViewController *m_pShakeVC;

@end
