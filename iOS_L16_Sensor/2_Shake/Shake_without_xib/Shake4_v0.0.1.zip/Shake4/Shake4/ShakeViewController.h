//
//  ShakeViewController.h
//  Shake4
//
//  Created by goodmao on 12-7-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShakeViewController : UIViewController

@end
