//
//  ShakeViewController.m
//  Shake4
//
//  Created by goodmao on 12-7-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ShakeViewController.h"

@interface ShakeViewController ()

@end

@implementation ShakeViewController


//================================================================================

#pragma mark -

//================================================================================
// 
// 说明：摇晃动作开始。
// 注意：模拟器中响应 motionBegan: 而不响应 motionEnded:。
//
//================================================================================

//事件处理方法
-(void)shakeME
{
	UIAlertView *alert = [[UIAlertView alloc]
						  initWithTitle:@"Hello"
						  message:@"我检测到晃动了!"
						  delegate:nil
						  cancelButtonTitle:@"OK"
						  otherButtonTitles:nil];
	[alert show];
	[alert release];	
}

//================================================================================
//
// Called when the view is about to made visible. 
// Default does nothing
//
//================================================================================

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
	
    //向消息中心注册观察者，以便获取"shake"消息，即：摇晃事件
	[[NSNotificationCenter defaultCenter]
         addObserver:self
            selector:@selector(shakeME)
                name:@"shake"
              object:nil];
}


//================================================================================
//
//  Called when the view is dismissed, covered or otherwise hidden. 
//  Default does nothing
//
//================================================================================

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
    
    //从消息中心移除观察者，不再获取"shake"消息
	[[NSNotificationCenter defaultCenter]
      removeObserver:self
                name:@"shake"
              object:nil];
}

#pragma mark -

//================================================================================
 

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



@end
